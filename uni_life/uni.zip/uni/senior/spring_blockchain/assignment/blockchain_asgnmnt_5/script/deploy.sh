PRIVATE_KEY=0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80
LOCAL_NET='http://127.0.0.1:8545'

forge create src/contracts/AuctionRepository.sol:AuctionRepository --rpc-url $LOCAL_NET --private-key $PRIVATE_KEY
forge create src/contracts/DeedRepository.sol:DeedRepository --rpc-url $LOCAL_NET --private-key $PRIVATE_KEY --constructor-args "Ultra Auction NFT" "UANFT"
