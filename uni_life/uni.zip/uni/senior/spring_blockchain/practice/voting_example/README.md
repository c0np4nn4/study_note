# Requirements
- [Installation, Foundry Book](https://book.getfoundry.sh/getting-started/installation)

```bash
# Using Foundryup
curl -L https://foundry.paradigm.xyz | bash
```

# Run test

```bash
ls -l
# total 16
# -rw-r--r--  1 aaron  staff  178 May 30 23:10 README.md
# -rw-r--r--  1 aaron  staff  170 May 30 23:05 foundry.toml
# drwxr-xr-x  3 aaron  staff   96 May 30 22:50 lib
# drwxr-xr-x  4 aaron  staff  128 May 30 23:02 src
# drwxr-xr-x  3 aaron  staff   96 May 30 23:02 test

# Test
forge test --match-contract VotingTest

# Test with detail execution tracing
forge test --match-contract VotingTest -vvvv
```
