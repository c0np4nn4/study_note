#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// typedef enum _Tag { TNIL, TINT, TSTR, TDUO, TERROR } Tag;
typedef enum _Tag { TERROR, TNIL, TINT, TSTR, TDUO } Tag;
typedef char *str;
typedef struct _Pair *duo;

typedef struct _Data {
  Tag tag;
  union {
    int ival;
    str sval;
    duo pval;
  };
} Data;

typedef struct _Pair {
  Data d[2];
} Pair;

char *substr(char *input, int i_begin, int i_end) {
  int cnt = 0;
  int size = (i_end - i_begin) + 2;
  char *str = (char *)malloc(size);

  memset(str, 0, size);

  for (int i = i_begin; i <= i_end; i++) {
    str[cnt] = input[i];
    cnt++;
  }

  return str;
}

Data mkint(int i) {
  Data d = {.tag = TINT, .ival = i};

  return d;
}

Data mkstr(str s) {
  Data d = {.tag = TSTR, .sval = s};

  return d;
}

Data cons(Data a, Data b) {
  Pair p = {.d = {a, b}};

  Data d = {.tag = TDUO, .pval = &p};

  return d;
}

const Data nil = {.tag = TNIL, .pval = NULL};

void get_result_str(Data d, str s) {
  switch (d.tag) {
  case TINT:
    sprintf(s, "(INT, %d)", d.ival);
    break;
  case TSTR:
    sprintf(s, "(STR, \'%s\')", d.sval);
    break;
  case TNIL:
    sprintf(s, "NIL");
    break;
  default:
    sprintf(s, "Error: unknown data type");
    break;
  }

  s[strlen(s)] = '\0';

  // printf("[get_result_str] s: %s\n", s);
  // printf("[get_result_str] s(len): %lu\n", strlen(s));
}

void print_duo(Data _d) {
  Data d_first = _d.pval->d[0];
  Data d_second = _d.pval->d[1];

  char res_first[80];
  char res_second[80];

  memset(res_first, 0, 80);
  memset(res_second, 0, 80);

  // printf("111 %s\n", res_second);
  get_result_str(d_first, res_first);
  get_result_str(d_second, res_second);
  // printf("222 %s\n\n", res_second);

  printf("(%s . %s)\n", res_first, res_second);
}

int main() {
  const size_t SZ = 80;
  char input[SZ + 1];
  Data d;

  while (fgets(input, 80, stdin) != NULL) {
    input[strlen(input) - 1] = '\0';

    // if (input[0] == '\n') {
    //   memset(input, 0, 80);

    //   continue;
    // }

    // INT
    if (isdigit(input[0])) {
      int val = 0;
      int idx = 0;

      while (input[idx] != '\0') {
        val = val * 10 + (input[idx++] - '0');
      }

      d = mkint(val);
    }

    // STR
    else if ('\"' == input[0]) {
      char buf[80];
      int idx = 1;
      int b_idx = 0;

      while (input[idx] != '\"') {
        if (input[idx] == '\\' && input[idx + 1] == '\"') {
          buf[b_idx++] = '\"';
          idx += 2;
          continue;
        }
        buf[b_idx++] = input[idx++];
      }
      buf[b_idx] = '\0';

      d = mkstr(buf);

    }
    // NIL
    else if ('n' == input[0]) {
      if (input[1] == 'i') {
        if (input[2] == 'l') {
          d = nil;
        }
      }
    }

    // DUO
    else if ('(' == input[0]) {

      Data d_first;
      Data d_second;

      str w_first = strtok(input, ".");
      str w_second = strtok(NULL, ".");

      str buf_first = substr(w_first, 1, strlen(w_first) - 2);
      str buf_second = substr(w_second, 1, strlen(w_second) - 2);

      // first
      {
        // INT
        if (isdigit(buf_first[0])) {
          int val = 0;
          int idx = 0;

          while (buf_first[idx] != '\0') {
            val = val * 10 + (buf_first[idx++] - '0');
          }

          d_first = mkint(val);
        }

        // STR
        else if ('\"' == buf_first[0]) {
          char buf[80];
          int idx = 1;
          int b_idx = 0;

          while (buf_first[idx] != '\"') {
            if (buf_first[idx] == '\\' && buf_first[idx + 1] == '\"') {
              buf[b_idx++] = '\"';
              idx += 2;
              continue;
            }
            buf[b_idx++] = buf_first[idx];
            idx++;
          }
          buf[b_idx] = '\0';

          d_first = mkstr(buf);

        }
        // NIL
        else if ('n' == buf_first[0]) {
          if (buf_first[1] == 'i') {
            if (buf_first[2] == 'l') {
              d_first = nil;
            }
          }
        }

        else {
          Data dummy;
          d_first = dummy;
        }
      }

      // second
      {
        // INT
        if (isdigit(buf_second[0])) {
          int val = 0;
          int idx = 0;

          while (buf_second[idx] != '\0') {
            val = val * 10 + (buf_second[idx++] - '0');
          }

          d_second = mkint(val);
        }

        // STR
        else if ('\"' == buf_second[0]) {
          char buf_2[80];
          int idx = 1;
          int b_idx = 0;

          while (buf_second[idx] != '\"') {
            if (buf_second[idx] == '\\' && buf_second[idx + 1] == '\"') {
              buf_2[b_idx++] = '\"';
              idx += 2;
              continue;
            }
            buf_2[b_idx++] = buf_second[idx++];
          }
          buf_2[b_idx] = '\0';

          d_second = mkstr(buf_2);

        }
        // NIL
        else if ('n' == buf_second[0]) {
          if (buf_second[1] == 'i') {
            if (buf_second[2] == 'l') {
              d_second = nil;
            }
          }
        }

        else {
          Data dummy;
          d_second = dummy;
        }
      }

      d = cons(d_first, d_second);
    }

    // ERROR
    else {
      Data dummy = {.tag = TERROR, .pval = NULL};
      d = dummy;
    }

    // print out
    switch (d.tag) {
    case TINT:
      printf("(INT, %d)\n", d.ival);
      break;
    case TSTR:
      printf("(STR, \'%s\')\n", d.sval);
      break;
    case TNIL:
      printf("NIL\n");
      break;
    case TDUO:
      print_duo(d);
      break;
    default:
      fputs("Error: unknown data type\n", stderr);
      break;
    }
  }
}
