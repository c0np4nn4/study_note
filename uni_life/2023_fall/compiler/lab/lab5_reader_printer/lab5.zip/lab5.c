#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFFER_SIZE 1024

typedef enum { TINT, TSTR, TDUO, TNIL } DataType;

typedef struct Duo {
  struct Data *d[2];
} Duo;

typedef struct Data {
  DataType tag;
  union {
    int ival;
    char *sval;
    Duo *pval;
  };
} Data;

Data nil = {TNIL};
char input[BUFFER_SIZE];
char *cursor;

Data *cons(Data *a, Data *b) {
  Duo *p = malloc(sizeof(Duo));
  p->d[0] = a;
  p->d[1] = b;
  Data *d = malloc(sizeof(Data));
  d->tag = TDUO;
  d->pval = p;
  return d;
}

void prdata(Data *d) {
  switch (d->tag) {
  case TINT:
    printf("%d", d->ival);
    break;
  case TSTR:
    printf("'%s'", d->sval);
    break;
  case TDUO:
    printf("(");
    prdata(d->pval->d[0]);
    if (d->pval->d[1]->tag != TNIL) {
      printf(" ");
      prdata(d->pval->d[1]);
    }
    printf(")");
    break;
  case TNIL:
    break;
  }
}

Data *rddata() {
  while (isspace(*cursor))
    cursor++; // Skip whitespaces

  if (*cursor == '(') {
    cursor++;
    Data *first = rddata();
    while (isspace(*cursor))
      cursor++; // Skip whitespaces
    if (*cursor == '.') {
      cursor++;
      while (isspace(*cursor))
        cursor++; // Skip whitespaces
      Data *second = rddata();
      return cons(first, second);
    } else if (*cursor == ')') {
      cursor++;
      return cons(first, &nil);
    } else {
      Data *second = rddata();
      return cons(first, second);
    }
  } else if (isdigit(*cursor) || *cursor == '-') {
    char number[BUFFER_SIZE];
    int i = 0;
    while (isdigit(*cursor) || *cursor == '-') {
      number[i++] = *cursor;
      cursor++;
    }
    number[i] = '\0';
    Data *d = malloc(sizeof(Data));
    d->tag = TINT;
    d->ival = atoi(number);
    return d;
  } else if (*cursor == '"') {
    cursor++; // Skip the opening double quote
    char *start = cursor;
    while (*cursor != '"') {
      if (*cursor == '\0') {
        fprintf(stderr, "Error: Closing double quote expected\n");
        exit(EXIT_FAILURE);
      }
      cursor++;
    }
    *cursor = '\0';
    cursor++; // Skip the closing double quote
    Data *d = malloc(sizeof(Data));
    d->tag = TSTR;
    d->sval = strdup(start);
    return d;
  } else if (*cursor == 'N') {
    cursor += 3; // Skip "NIL"
    return &nil;
  } else if (*cursor == ')') {
    cursor++;
    return &nil;
  } else {
    fprintf(stderr, "Error: Unexpected character '%c'\n", *cursor);
    exit(EXIT_FAILURE);
  }
  return NULL;
}

int main() {
  while (input == fgets(input, BUFFER_SIZE, stdin)) {
    cursor = input;
    Data *data = rddata();
    prdata(data);
    printf("\n");
  }
  return 0;
}
