# cosine similarity analysis
from math import prod, sqrt

def get_cos_sim(a: list, b: list):
    numerator = sum(c * d for (c, d) in zip(a, b))
    denominator = sqrt(sum(pow(c, 2) for c in a)) * sqrt(sum(pow(c, 2) for c in b))

    return numerator / denominator

p = [[3, 7, 1, 2],
     [7, 1, 5, 5],
     [6, 3, 5, 1],
     [1, 2, 3, 4],
     [6,12, 2, 3],
     [5, 4, 3, 2]]

res_list = []
val_list = []

for i in range(0, len(p)):
    for j in range(i + 1, len(p)):
        res = get_cos_sim(p[i], p[j])
        res_list.append(((i, j), res))
        val_list.append(res)

for i in range(0, len(res_list)):
    if res_list[i][1] == max(val_list):
        print(f"max: {res_list[i][0]}, {res_list[i][1]}")
    if res_list[i][1] == min(val_list):
        print(f"min: {res_list[i][0]}, {res_list[i][1]}")


