from graphviz import Digraph

s = Digraph('BTree', filename='My_Tree.gv', node_attr={'shape': 'record'})

s.node('V1', '<left>     | <data>  7 | <right>      ')
s.node('V2', '<left>     | <data>  3 | <right>      ')
s.node('V3', '<left>     | <data> 11 | <right>      ')
s.node('V4', '<left>     | <data>  1 | <right>      ')
s.node('V5', '<left>     | <data>  5 | <right>      ')
s.node('V6', '<left>     | <data>  9 | <right>      ')
s.node('V7', '<left>     | <data> 13 | <right>      ')
s.node('V8', '<left>     | <data>  0 | <right>      ')
s.node('V9', '<left>     | <data>  2 | <right>      ')
s.node('VA', '<left>     | <data>  4 | <right>      ')
s.node('VB', '<left>     | <data>  6 | <right>      ')
s.node('VC', '<left>     | <data>  8 | <right>      ')
s.node('VD', '<left>     | <data> 10 | <right>      ')
s.node('VE', '<left>     | <data> 12 | <right>      ')
s.node('VF', '<left>     | <data> 15 | <right>      ')
s.node('VG', '<left>     | <data> 14 | <right>      ')

s.edge('V1:left'  ,  'V2:data',   color='red', dir='none', tailport='w' )
s.edge('V1:right'  ,  'V3:data',   color='black', dir='arrow', tailport='e' )

s.edge('V2:left'  ,  'V4:data',   color='black', tailport='w' )
s.edge('V2:right'  ,  'V5:data',   color='black')

s.edge('V3:left'  ,  'V6:data',   color='red', dir='none')
s.edge('V3:right'  ,  'V7:data',   color='red', dir='none', tailport='e' )

s.edge('V4:left'  ,  'V8:data',   color='black', dir='arrow')
s.edge('V4:right'  ,  'V9:data',   color='black', dir='arrow')

s.edge('V5:left'  ,  'VA:data',   color='black', dir='arrow')
s.edge('V5:right'  ,  'VB:data',   color='black', dir='arrow')

s.edge('V6:left'  ,  'VC:data',   color='black', dir='arrow')
s.edge('V6:right'  ,  'VD:data',   color='black', dir='arrow')

s.edge('V7:left'  ,  'VE:data',   color='black', dir='arrow')
s.edge('V7:right'  ,  'VF:data',   color='black', dir='arrow')

s.edge('VF:left'  ,  'VG:data',   color='red', dir='none')

s.view()

